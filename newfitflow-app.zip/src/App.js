
import React from 'react';

function App() {
  return (
    <div>
      <h1>NewFitFlow</h1>
      <p>React + Firebase Hosting App</p>
    </div>
  );
}

export default App;
